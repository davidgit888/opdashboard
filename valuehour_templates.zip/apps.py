from django.apps import AppConfig


class ValuehourConfig(AppConfig):
    name = 'valuehour'
